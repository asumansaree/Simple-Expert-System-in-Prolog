% knowledge base
% possible flights between some of the cities in Turkey
flight(istanbul,ankara,1).     % fact: Istanbul and Ankara has a flight with cost 1.
flight(ankara,istanbul,1). 
flight(canakkale,erzincan,6). 
flight(erzincan,canakkale,6). 
flight(erzincan,antalya,3).    
flight(antalya,erzincan,3).    
flight(antalya,diyarbakir,4).   
flight(diyarbakir,antalya,4).           
flight(izmir,istanbul,2).          
flight(istanbul,izmir,2).          
flight(izmir,ankara,6).           
flight(ankara,izmir,6).           
flight(istanbul,rize,4).           
flight(rize,istanbul,4).           
flight(ankara,diyarbakir,8).        
flight(diyarbakir,ankara,8).  
flight(ankara,rize,5).             
flight(rize,ankara,5).                     
flight(ankara,van,4).               
flight(van,ankara,4).               
flight(van,gaziantep,3).           
flight(gaziantep,van,3).           
flight(antalya,izmir,2).         
flight(izmir,antalya,2). 
flight(sivas,istanbul,5).           
flight(istanbul,sivas,5).           
flight(mersin,canakkale,3).         
flight(canakkale,mersin,3). 

% rules

% checks if a route between X and Y exists with cost C 
connection(city_1,city_2,cost_betw_cities) :- schedule(city_1,city_2,cost_betw_cities,[]). 

schedule(city_1,city_2,cost_betw_cities,_) :- 
	flight(city_1,city_2,cost_betw_cities).

schedule(city_1,city_2,cost_betw_cities,visited_cities_list) :- 
	% hold the list of visited cities
    \+ member(city_1,visited_cities_list), 
    % chech both direct and indirect flights
	flight(city_1,mid_city,Cost1), 	
	schedule(mid_city,city_2,Cost2,[city_1|visited_cities_list]),
	city_1 \= city_2, cost_betw_cities is Cost1 + Cost2.