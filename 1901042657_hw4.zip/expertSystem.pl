:- style_check(-singleton).
% simple expert system in Prolog for scheduling of classes. 
% room: ID, capacity, Occupancy info(hour(8-17), course name), equipment[]
:-dynamic(room/4).
:-dynamic(courseHour/3).
% course: ID, instructor, capacity, startHour, endHour, room, needs[]
:-dynamic(course/7).
% instructor: ID, course taught, preferences[]
:-dynamic(instructor/3).
% student: ID, courses attended[], handicapped
:-dynamic(student/3).

room(z23, 100, [
  courseHour(10, 12, algo),  
  courseHour(11, 15, comp_org)  
], [projector, smart_board, handicapped]).

room(z06, 80, [
  courseHour(14, 16, pl)  
], [smart_board]).

room(z10, 80, [
  courseHour(13, 15, software)  
], [projector, handicapped]).

instructor(didem_gozupek, algo, projector).
instructor(yakup_genc, pl, handicapped).
instructor(habil_kalkan, software, projector).
instructor(alp_bayrakci, comp_org, smart_board).

course(algo, didem_gozupek, 50, 10, 12, z23, projector).
course(pl, yakup_genc, 50, 14, 16, z23, handicapped).
course(software, habil_kalkan, 50, 13, 15, z06, projector).
course(comp_org, alp_bayrakci, 50, 11, 15, z10, smart_board).

student(1, [algo, pl, software, comp_org], no).
student(2, [pl, software, comp_org], yes).
student(3, [software, comp_org], no).
student(4, [comp_org], no).
student(5, [algo, pl, software, comp_org], yes).
student(6, [algo, pl, software], no).
student(7, [algo, pl], no).
student(8, [algo], no).

% add course
add_course(C_ID, Instructor, Capacity, StartHour, EndHour, Room, Needs):-
    % Check if a course with the given ID does not already exist in the database
    \+ course(C_ID, _, _, _, _, _, _),
    % Check if an instructor with the given name exists in the database
    (   instructor(Instructor, _, _)
    ->  true % If the instructor exists, do nothing
    ;   % If the instructor does not exist, create a new instructor
        assertz(instructor(Instructor, [], []))
    ),
    % Check if the given start hour is before the given end hour
    StartHour < EndHour,
    % Check if there is a room with the given name in the database
    ( room(Room, _, Occupancy, _)
    -> % If the room exists, check for conflicts with the start hour of the new course
    ( member(courseHour(StartHour, _, _), Occupancy)
    -> % If there is a conflict, print a message and return false
    write('There is a conflict with the start hour of the new course in the given room.'),
    false
    ; % If there is no conflict, continue
    true
    )
    ; % If the room does not exist, print a message and return false
    write('There is no room with the given name in the database. First add room.'),
    false
    ),
    % If all checks are successful, add the new course to the database
    assertz(course(C_ID, Instructor, Capacity, StartHour, EndHour, Room, Needs)).

% add student
add_student(S_ID, CoursesTaken, IsHandicapped):-
    % Check if a student with the given ID does not already exist in the database
    \+ student(S_ID, _, _),
    % If a student with the given ID does not exist, add the new student to the database
    assertz(student(S_ID, CoursesTaken, IsHandicapped)).

% add room
add_room(R_ID, Capacity, Occupancy, Equipment):-
    % Check if a room with the given ID already exists in the database
    (   room(R_ID, _, _, _)
    ->  % If the room exists, update its capacity, occupancy, and equipment
        retract(room(R_ID, _, _, _)),
        assertz(room(R_ID, Capacity, Occupancy, Equipment))
    ;   % If the room does not exist, create a new room
        assertz(room(R_ID, Capacity, Occupancy, Equipment))
    ).

% Check which room can be assigned to a given class.
assign_room_to_class(GivenClass, GivenRoom):-
    GivenClass = course(_, _, Capacity, _, _, _, Needs),
    room(GivenRoom, RoomCapacity, _, RoomEquipment),
    ( RoomCapacity >= Capacity -> 
        (member(Needs, RoomEquipment) ->
            write(GivenRoom), nl
            ; write('The equipment needs of the given course are not met by the given room.'), nl, !, fail
        )
    ; write('The capacity of the given room is insufficient for the given course.'), nl, !, fail
    ).
assign_room_to_class(_, _):-
    write('There is no room that can accommodate the given course.'),
    false.

% Check which room can be assigned to which classes.
list_assignable_classes(GivenRoom):-
    % For all member in room database, list all of the assignable classes for that room
    room(GivenRoom, RoomCapacity, Occupancy, RoomEquipment),
    findall(Class, (course(Class, _, CourseCapacity, StartTime, EndTime, _, CourseEquipment),
    CourseCapacity =< RoomCapacity,
    member(CourseEquipment, RoomEquipment)),
    Classes),
    write('The following classes can be assigned to room '),
    write(GivenRoom),
    write(':'),
    nl,
    print_classes(Classes).

    print_classes([]).
    print_classes([Class|Classes]) :-
    write(' '),
    write(Class),
    nl,
    print_classes(Classes).

% Check whether a student can be enrolled to a given class.
enroll_student(GivenStudent, GivenClass):-
    GivenStudent = student(_, _, IsHandicapped),
    ( IsHandicapped = no ->
        true
    ; course(GivenClass, _, _, _, _, GivenRoom, _),
      room(GivenRoom, _, _, Equipment),
      member(handicapped, Equipment)
    ).

% Check which classes a student can be assigned.
enrollable_classes(GivenStudent):-
    GivenStudent = student(_, _, IsHandicapped),
    (IsHandicapped = no ->
    findall(Class, course(Class, _, _, _, _, _, _), Classes)
    ; findall(Class, (course(Class, _, _, _, _, Room, _), room(Room, _, _, RoomEquipment), member(handicapped, RoomEquipment)), Classes)
    ),
    write('The following courses are enrollable for the given student: '),
    write(Classes), nl.



